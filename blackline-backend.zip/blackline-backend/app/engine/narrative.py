"""Turns the scored, financial, and comparables data into the human-readable
text analyse.html displays: the four per-dimension `clauses`, the
`strengths` / `risks` lists, and the executive `summary`.

Every sentence here is built from a real computed value (yield, comparable
count, EPC rating, ...) via templates — nothing is invented. This is the
default and *only* path unless OPENAI_API_KEY is set, in which case the
deterministic text is handed to the model as grounding context and it is
asked only to rewrite/tighten the summary paragraph, not to introduce new
claims. If that call fails or times out for any reason, the deterministic
summary is used untouched — narrative generation never blocks or breaks
the pipeline.
"""
from __future__ import annotations

import httpx

from app.config import settings
from app.engine.comparables import ComparablesResult, RentEstimate
from app.engine.financial import FinancialAnalysis
from app.engine.scoring import BENCHMARK_NET_YIELD_PCT, ScoreBreakdown
from app.extractors.rightmove import ListingData
from app.schemas import Verdict


def _cashflow_clause(financials: FinancialAnalysis) -> str:
    yld = financials.net_yield_pct
    if yld >= BENCHMARK_NET_YIELD_PCT + 1:
        comparison = "well above the local BTL average"
    elif yld >= BENCHMARK_NET_YIELD_PCT:
        comparison = "in line with the local BTL average"
    else:
        comparison = f"below the {BENCHMARK_NET_YIELD_PCT:.1f}% benchmark for this strategy"
    cf_note = "" if financials.cashflow_monthly >= 0 else " — currently cashflow negative at this rent"
    return f"{yld:.1f}% net yield, {comparison}{cf_note}"


def _growth_clause(comparables: ComparablesResult, price: int, listing: ListingData) -> str:
    if comparables.sales:
        avg_comp = sum(p for _, p in comparables.sales) / len(comparables.sales)
        discount_pct = ((avg_comp - price) / avg_comp) * 100 if avg_comp else 0
        n = len(comparables.sales)
        if discount_pct > 3:
            clause = f"priced {discount_pct:.0f}% below {n} comparable sold price{'s' if n != 1 else ''} nearby"
        elif discount_pct >= -3:
            clause = f"broadly in line with {n} comparable sale{'s' if n != 1 else ''} nearby"
        else:
            clause = f"priced {abs(discount_pct):.0f}% above {n} comparable sale{'s' if n != 1 else ''} nearby"
    else:
        clause = "no verified comparable sales evidence yet for this area"
    if listing.price_reduced:
        clause += "; the asking price has already been reduced once"
    return clause


_EPC_LANGUAGE = {
    "A": "already at the top EPC band — limited upside from further improvement",
    "B": "already efficient (EPC B) — limited upside from further improvement",
    "C": "EPC C — modest scope for a cosmetic refresh",
    "D": "EPC D — some scope for a light refresh to lift rent or value",
    "E": "EPC E — meaningful scope to add value through improvement, though budget for it",
    "F": "EPC F — significant improvement required, factor this into any offer",
    "G": "EPC G — substantial works likely needed before letting or resale",
}


def _value_add_clause(listing: ListingData) -> str:
    epc = (listing.epc_rating or "").upper()
    base = _EPC_LANGUAGE.get(epc, "EPC rating not available — condition and improvement potential unverified")
    text = f"{listing.description} {' '.join(listing.key_features)}".lower()
    if any(kw in text for kw in ("extend", "extension", "loft", "side return", "stpp", "planning")):
        base += "; the listing signals extension/development potential, subject to planning"
    return base


def _security_clause(listing: ListingData, comparables: ComparablesResult, rent: RentEstimate) -> str:
    parts = []
    if comparables.sales:
        parts.append(f"{len(comparables.sales)} comparable sale(s) as evidence")
    else:
        parts.append("no comparable sales evidence found")
    parts.append(f"{listing.tenure.lower()} tenure confirmed" if listing.tenure else "tenure unconfirmed")
    parts.append(
        "rent estimate based on live comparable listings"
        if rent.method == "live_comparables"
        else "rent estimate is modelled, not yet verified against live listings"
    )
    return ", ".join(parts)


def build_clauses(listing, financials, comparables, rent) -> dict:
    return {
        "cashflow": _cashflow_clause(financials),
        "growth": _growth_clause(comparables, financials.purchase, listing),
        "valueAdd": _value_add_clause(listing),
        "security": _security_clause(listing, comparables, rent),
    }


def build_strengths_and_risks(
    listing: ListingData,
    financials: FinancialAnalysis,
    comparables: ComparablesResult,
    rent: RentEstimate,
    scores: ScoreBreakdown,
) -> tuple[list[str], list[str]]:
    strengths: list[str] = []
    risks: list[str] = []

    if comparables.sales:
        avg_comp = sum(p for _, p in comparables.sales) / len(comparables.sales)
        if avg_comp > financials.purchase:
            discount_pct = (avg_comp - financials.purchase) / avg_comp * 100
            strengths.append(f"Priced ~{discount_pct:.0f}% below {len(comparables.sales)} comparable sold prices nearby")
    else:
        risks.append("No comparable sales evidence available yet — valuation confidence is limited")

    if financials.cashflow_monthly > 0:
        strengths.append(f"Cashflow positive at ~£{financials.cashflow_monthly}/month under the modelled assumptions")
    else:
        risks.append(f"Cashflow negative at ~£{financials.cashflow_monthly}/month under the modelled assumptions")

    if financials.net_yield_pct >= BENCHMARK_NET_YIELD_PCT:
        strengths.append(f"Net yield of {financials.net_yield_pct:.1f}% exceeds the {BENCHMARK_NET_YIELD_PCT:.1f}% benchmark")

    if rent.method != "live_comparables":
        risks.append("Rental figure is modelled rather than verified against live comparable listings")

    epc = (listing.epc_rating or "").upper()
    if epc in ("E", "F", "G"):
        risks.append(f"EPC rated {epc} — likely to need improvement work, and possibly ahead of tightening MEES rules")
    if not listing.epc_rating:
        risks.append("No EPC on record — condition and running costs are unverified")

    if listing.tenure and listing.tenure.upper() == "LEASEHOLD":
        risks.append("Leasehold — check remaining lease term and service charges before offering")

    if listing.price_reduced:
        strengths.append("Asking price has already been reduced once, suggesting some room to negotiate further")

    if not strengths:
        strengths.append("No standout strengths identified from the available listing data")
    if not risks:
        risks.append("No material risks identified from the available listing data")

    return strengths[:4], risks[:4]


def suggested_offer_range(price: int, verdict: Verdict) -> tuple[int, int]:
    if verdict in (Verdict.strongbuy, Verdict.buy):
        low_pct, high_pct = 0.95, 0.99
    elif verdict == Verdict.invest:
        low_pct, high_pct = 0.92, 0.97
    else:
        low_pct, high_pct = 0.88, 0.94
    low = round(price * low_pct / 500) * 500
    high = round(price * high_pct / 500) * 500
    return low, high


def _deterministic_summary(
    listing: ListingData,
    financials: FinancialAnalysis,
    comparables: ComparablesResult,
    scores: ScoreBreakdown,
) -> str:
    low, high = suggested_offer_range(financials.purchase, scores.verdict)
    comps_sentence = (
        f"Priced against {len(comparables.sales)} comparable sale(s) within the {listing.postcode_outcode or 'local'} area, "
        if comparables.sales
        else "No verified comparable sales were available for this area, so treat the valuation with extra caution. "
    )
    yield_sentence = (
        f"Net yield of {financials.net_yield_pct:.1f}% "
        f"{'exceeds' if financials.net_yield_pct >= BENCHMARK_NET_YIELD_PCT else 'sits below'} "
        f"the {BENCHMARK_NET_YIELD_PCT:.1f}% benchmark for this strategy. "
    )
    return (
        f"{comps_sentence}{yield_sentence}"
        f"Suggested offer range: £{low:,}–£{high:,}."
    )


async def _try_openai_polish(deterministic_summary: str, address: str) -> str | None:
    if not settings.openai_api_key:
        return None
    prompt = (
        "Rewrite the following UK property-investment summary in 2-3 tight "
        "sentences for a professional investor. Do not add any facts, "
        "figures, or claims that are not already present in the text — "
        "only rephrase for clarity and flow.\n\n"
        f"Property: {address}\n\nText:\n{deterministic_summary}"
    )
    try:
        async with httpx.AsyncClient(timeout=8.0) as client:
            resp = await client.post(
                "https://api.openai.com/v1/chat/completions",
                headers={"Authorization": f"Bearer {settings.openai_api_key}"},
                json={
                    "model": settings.openai_model,
                    "messages": [{"role": "user", "content": prompt}],
                    "temperature": 0.3,
                    "max_tokens": 200,
                },
            )
            resp.raise_for_status()
            data = resp.json()
            return data["choices"][0]["message"]["content"].strip()
    except Exception:
        return None


async def build_summary(
    listing: ListingData,
    financials: FinancialAnalysis,
    comparables: ComparablesResult,
    scores: ScoreBreakdown,
) -> str:
    deterministic = _deterministic_summary(listing, financials, comparables, scores)
    polished = await _try_openai_polish(deterministic, listing.address)
    return polished or deterministic
